package com.sushu.appointmentmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
